﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Linq;
using Core.Model;
using Core.Storage;

namespace Core.DAO
{
    public class AutorDAO
    {
        private readonly Storage<Autor> _storage;
        private readonly List<Autor> _autori;

        public AutorDAO()
        {
            _storage = new Storage<Autor>("autori.csv");
            _autori = _storage.Load();
        }
        public List<Autor> GetAll()
        {
            return _autori.ToList();
        }
        public Autor? GetById(int id)
        {
            return _autori.FirstOrDefault(a => a.Id == id);
        }

        public Autor? Add(Autor noviAutor)
        {
            // Proveravamo da li već postoji autor sa istim brojem lične karte
            bool postoji = _autori.Any(a => a.BrojLK == noviAutor.BrojLK);

            if (postoji)
            {
                // Već postoji, ne dozvoljavamo duplikat
                return null;
            }

            // Ako ne postoji, dodeljujemo ID i čuvamo
            noviAutor.Id = GenerateId();
            _autori.Add(noviAutor);
            _storage.Save(_autori);
            return noviAutor;
        }

        public Autor? Update(Autor izmenjeniAutor)
        {
            bool postoji = _autori.Any(a => a.BrojLK == izmenjeniAutor.BrojLK && a.Id != izmenjeniAutor.Id);
            if (postoji)
            {
                return null;
            }

            var postojeci = GetById(izmenjeniAutor.Id);

            if (postojeci != null)
            {
                postojeci.Id = izmenjeniAutor.Id;
                postojeci.Ime = izmenjeniAutor.Ime;
                postojeci.Prezime = izmenjeniAutor.Prezime;
                postojeci.DatumRodjenja = izmenjeniAutor.DatumRodjenja;
                postojeci.AdresaId = izmenjeniAutor.AdresaId;
                postojeci.Telefon = izmenjeniAutor.Telefon;
                postojeci.Email = izmenjeniAutor.Email;
                postojeci.BrojLK = izmenjeniAutor.BrojLK;
                postojeci.GodineIskustva = izmenjeniAutor.GodineIskustva;
                _storage.Save(_autori);
            }
            return postojeci;
            
        }
        public Autor? Remove(int id)
        {
            var aut = GetById(id);
            if(aut!= null)
            {
                _autori.Remove(aut);
                _storage.Save(_autori);
                return aut;
            }
            return null;
        }


        // Koriscen materijal sa vezbi CRUDExample 
        // Sortiranje po kriterijumu i direkciji koja moze
        // biti rastuca ili opadajuca
        public List<Autor> GetSorted(int page, int pageSize, string sortCriteria, SortDirection sortDirection)
        {
            IEnumerable<Autor> autori = _autori;

            // Sortiranje prema prosleđenom kriterijumu
            switch (sortCriteria)
            {
                case "Id":
                    autori = _autori.OrderBy(a => a.Id);
                    break;
                case "Ime":
                    autori = _autori.OrderBy(a => a.Ime);
                    break;
                case "Prezime":
                    autori = _autori.OrderBy(a => a.Prezime);
                    break;
                case "Email":
                    autori = _autori.OrderBy(a => a.Email);
                    break;
                default:
                    autori = _autori.OrderBy(a => a.Id);
                    break;
            }

            // Promena smera ukoliko je opadajući
            if (sortDirection == SortDirection.Descending)
            {
                autori = autori.Reverse();
            }

            // Paginacija
            autori = autori.Skip((page - 1) * pageSize).Take(pageSize);

            return autori.ToList();
        }




        private int GenerateId()
        {
            return _autori.Any() ? _autori.Max(a => a.Id) + 1 : 1;
        }
    }
}
